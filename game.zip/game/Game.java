package game;

public class Game {

    public static void main(String[] args) {

        Deck deck = new Deck();

        System.out.println("Printing all cards in the deck:\n");
        deck.printAllCards();

        System.out.println("\nTotal number of cards: " + deck.countCards());
    }
}
