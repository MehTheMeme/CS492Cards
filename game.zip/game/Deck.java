package game;


import java.util.ArrayList;

public class Deck {

    private final ArrayList<Card> deck;

    public Deck() {
        deck = new ArrayList<Card>();

        // Create 52 cards
        for (int suit = 0; suit < 4; suit++) {
            for (int value = 0; value < 13; value++) {
                deck.add(new Card(suit, value));
            }
        }
    }

    public void printAllCards() {
        for (Card c : deck) {
            System.out.println(c);
        }
    }

    public int countCards() {
        return deck.size();
    }
}
