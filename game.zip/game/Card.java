package game;

public class Card {

    private final int suit;
    private final int value;

    private final String[] cardSuit = {"Spades", "Diamonds", "Hearts", "Clubs"};
    private final String[] cardValue = {"Ace", "2", "3", "4", "5",
                                  "6", "7", "8", "9", "10",
                                  "Jack", "Queen", "King"};

    public Card(int cSuit, int cValue) {
        suit = cSuit;
        value = cValue;
    }

    public int getSuit() {
        return suit;
    }

    public int getValue() {
        return value;
    }

    public String toString() {
        return cardValue[value] + " of " + cardSuit[suit];
    }
}
